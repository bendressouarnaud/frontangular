export class Classe{

    idcl : Number;
    libelle: string;

    // Methd :
    constructor(){}
}