export class RdvObjet{
    idrdv : number;
    nom : String;
    contact : String;
    email : String;
    activite : number;
    motif : number;
    heure : String;
    categorie : number;
    qualite : number;
    superviseur : number;
    resume : String;
    etat : number;
    dates : string;
    //
    invite : string;
    nomfonction : string;
    mailautre : string;
    lieu : String;

    constructor(){}
}