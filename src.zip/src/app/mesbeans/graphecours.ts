export class GrapheCours{

    cours : String;
    mois : Number;
    tot : Number;
    id : Number;

    // Methd :
    constructor(){}
}