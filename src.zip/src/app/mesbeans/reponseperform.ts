export class PerfRest{
    employe : String;
    an : number;
    libperf : String;
    libmois : String;
    valeur : number;
    idper : number;
    idemp : number;
    choix : number;
    mois : number;
    identifiant : String;
    annee : number;


    // Methd :
    constructor(){}
}