export class ListeItems{
    item_id : Number;
    item_text : String;

    constructor(){}
}