export class Utilisateur{
    iduser : number;
    nom : String;
    prenom : String;
    email : String;
    contact : String;
    idprofil : number;
    identifiant : String;
    motdepasse : String;

    constructor(){}
}