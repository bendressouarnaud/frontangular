export class RdvInfoRest {

    commercial : string;
    client : string;
    dates : string; 
    heure : string; 
    objet : string; 
    idrdv : string; 

    // Methd :
    constructor(){}
}