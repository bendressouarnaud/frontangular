export class Reprdv{
    nom : String;
    libelle : String;
    email : String;
    contact : String;
    dte : String;
    heure : String;
    presence : String;
    idrdv : number;

    // Methd :
    constructor(){}
}