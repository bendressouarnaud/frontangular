export class GrapheCours{

    cours : string;
    mois : Number;
    tot : Number;
    id: Number;

    // Methd :
    constructor(){}
}