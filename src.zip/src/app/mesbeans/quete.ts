export class Quete{
    code : String;

    // Methd :
    constructor(){}
}