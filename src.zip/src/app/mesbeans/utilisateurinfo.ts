export class UtilisateurInfo{
    nom : String;
    iduser : number;

    // Methd :
    constructor(){}
}