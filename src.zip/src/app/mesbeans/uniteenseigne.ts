export class Uniteenseigne{

    idue : Number;
    libelle: string;

    // Methd :
    constructor(){}
}