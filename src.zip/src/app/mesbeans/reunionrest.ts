export class ReunionRest{
    id : number;
    objet : String;
    emplacement : String;
    dte : String;
    heuredebut : String;
    duree : String;
    resume : String;
    rapport : String;

    constructor(){}
}