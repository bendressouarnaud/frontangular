export class RestPolice{
    IdClient : number;
    IdSite : number;
    IdQuittance : number;
    Police : String;

    constructor(){}
}