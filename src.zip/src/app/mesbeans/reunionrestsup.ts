export class ReunionRestSup{
    employe : String;
    objet : String;
    emplacement : String;
    dte : String;
    heuredebut : String;
    duree : String;
    rapport : String;

    constructor(){}
}