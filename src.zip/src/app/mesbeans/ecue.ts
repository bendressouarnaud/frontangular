export class Ecue{

    idecu : Number;
    libelle : string;
    idue : Number;    

    // Methd :
    constructor(){}
}