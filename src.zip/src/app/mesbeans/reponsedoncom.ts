export class ReponseDonCom{
    rdv : number;
    commerciaux : number;
    rapports : number;
    commentaires : number;

    // Methd :
    constructor(){}
}