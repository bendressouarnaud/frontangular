export class RdvComRest{

    commercial : string;
    superviseur : string;
    inspecteur : string; 
    dates : string; 
    heure : string; 
    objet : string; 
    client : string; 
    idrdv : number; 

    // Methd :
    constructor(){}
}