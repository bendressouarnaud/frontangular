export class Annee{
    idan : number;
    valeur : number;

    constructor(){}
}