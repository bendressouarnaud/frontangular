export class Reponse{
    element : String;
    profil : String;
    identifiant : String;

    // Methd :
    constructor(){}
}