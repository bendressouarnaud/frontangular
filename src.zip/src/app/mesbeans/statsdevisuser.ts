export class StatsDevisUser{

    auto : string;
    voyage : string;
    accident : string;
    mrh : string;

    constructor(){}
}