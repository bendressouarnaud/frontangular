export class RapportObjet{
    idrdv : number;
    actions : String;
    contenu : String;
    interlocuteurs : String;

    constructor(){}
}