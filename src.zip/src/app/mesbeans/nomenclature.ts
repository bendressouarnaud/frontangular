export class Nomenclature{
    idnom : number;
    libelle : String;

    constructor(){}
}