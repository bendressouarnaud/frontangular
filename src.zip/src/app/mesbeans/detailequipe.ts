export class Detailequipe{

    iddet : Number;
    libelle : string;  

    // Methd :
    constructor(){}
}