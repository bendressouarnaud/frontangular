export class DonneGraphe{

    annee : Number;
    mois : Number;
    tot : Number;
    libmois: string;

    // Methd :
    constructor(){}
}