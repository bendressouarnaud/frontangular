export class TeamAgenda{

    commercial : string;
    heure: string;
    dte: string;

    // Methd :
    constructor(){}
}