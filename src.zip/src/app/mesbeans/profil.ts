export class Profil{
    code : String;
    libelle : String;
    idpro : Number;

    // Methd :
    constructor(){}
}