export class Activite{

    idact : Number;
    libelle : string;
    actif : Number;    

    // Methd :
    constructor(){}
}