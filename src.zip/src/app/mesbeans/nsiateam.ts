export class NsiaTeam{
    iduser : number;
    membre : String;

    constructor(){}
}