export class StatGen{

    idpro : Number;
    mois : Number;
    total : Number;
    code : String;

    // Methd :
    constructor(){}
}