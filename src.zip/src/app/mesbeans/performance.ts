export class Performance{
    identifiant : String;
    choix : number;
    annee : number;
    mois : number;
    valeur : number;

    constructor(){}
}