export class UserLog{

    identifiant : String;
    motdepasse : String;
    
    constructor(){}
}