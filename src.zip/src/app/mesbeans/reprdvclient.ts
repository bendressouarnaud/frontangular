export class RepRdvClient{
    commercial : String;
    client : String;
    dates : String;
    heure : String;
    nom : String;
    contact : String;
    id : Number;


    // Methd :
    constructor(){}
}