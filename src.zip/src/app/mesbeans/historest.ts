export class HistoRest{

    nom : string;
    profil : string;
    dates : string;
    heure : string;
    tache : string;   

    // Methd :
    constructor(){}
}