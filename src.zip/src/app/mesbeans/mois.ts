export class Mois{
    idm : number;
    libelle : String;

    constructor(){}
}