export class Rdv{
    idrdv : number;
    nom : String;
    contact : String;
    email : String;
    activite : number;
    motif : number;
    dates : Date;
    heure : String;
    categorie : number;
    qualite : number;
    superviseur : number;
    resume : String;
    etat : number;
    idcom : number;

    constructor(){}
}