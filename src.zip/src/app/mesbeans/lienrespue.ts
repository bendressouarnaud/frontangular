export class Lienrespue{

    idlue : Number;
    idres : Number;
    idue : Number;

    // Methd :
    constructor(){}
}