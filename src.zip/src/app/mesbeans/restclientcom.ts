export class RestClient{
    IdClient : number;
    RAISONSOCIALE : String;
    TELEP1 : String;

    constructor(){}
}