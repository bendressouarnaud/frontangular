export class Motif{
    idmot : number;
    libelle : String;
    actif : number;

    constructor(){}
}