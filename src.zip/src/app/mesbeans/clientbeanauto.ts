export class Clientbeanauto{

    idCliendDone : number;
    idClient : number;
    nom: String;
    prenom: String;
    contact: String;
    email: String;
    heure: String;
    civilite : number;
    activite : number;
    typeclient : number;
    energie : number;
    place : number;
    puissance : number;
    chargeutile : number;
    dureecontrat : number;
    offrecommerciale : number;
    plafond : number;
    indemnitemax : number;
    cout : number;
    dates : Date;

    constructor(){}
}