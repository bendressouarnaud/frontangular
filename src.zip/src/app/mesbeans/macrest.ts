export class MacRest{

    nom : string;
    profil : string;
    adresse : string; 

    // Methd :
    constructor(){}
}