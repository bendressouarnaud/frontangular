export class Detailtable{
    idnmd : number;
    libelle : String;
    idnom : number;

    constructor(){}
}