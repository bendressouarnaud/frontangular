export class Cours{
    idcou : number;
    idprof : number;
    idecue : number;
    idcl : number;
    temps : number;
    dates : Date;

    constructor(){}
}