export class DetailNomenclature{
    nomenclature : String;
    detail : String;
    idnmd : String;
    idnom: String;

    constructor(){}
}