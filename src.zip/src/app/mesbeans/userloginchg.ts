export class UserLogChg{

    identifiant : String;
    motdepasse : String;
    motdepassedeux : String;
    
    constructor(){}
}