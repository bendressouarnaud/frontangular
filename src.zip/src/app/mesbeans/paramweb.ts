export class ParamWeb{
    
    libelle : string;
    statut : string;   

    // Methd :
    constructor(){}
}