export class RepGraphe{

    annee : Number;
    mois : Number;
    tot : Number;

    // Methd :
    constructor(){}
}