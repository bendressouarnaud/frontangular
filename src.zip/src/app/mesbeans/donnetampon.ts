export class DonneTampon{

    somme: number[];
    sigle: string;

    // Methd :
    constructor(){}
}