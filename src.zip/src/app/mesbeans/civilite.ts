export class Civilite{
    idciv : number;
    libelle : number;

    constructor(){}
}