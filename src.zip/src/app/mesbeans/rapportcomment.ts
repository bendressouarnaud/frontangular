export class RapportComment{
    idrdv : number;
    idrap : number;
    dates : String;
    heure : String;
    contenu : String;
    actions : String;
    commentaires : String;

    constructor(){}
}