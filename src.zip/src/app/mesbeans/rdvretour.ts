export class RdvRetour{
    idrdv : number;
    nom : String;
    contact : String;
    email : String;
    activite : number;
    motif : number;
    heure : String;
    categorie : number;
    qualite : number;
    superviseur : number;
    resume : String;
    etat : number;
    dates : Date;
    //
    invite : string;
    nomfonction : string;
    mailautre : string;
    lieu: string;

    constructor(){}
}