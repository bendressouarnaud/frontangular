export class ReponseUser{
    nom : String;
    prenom : String;
    email : String;
    contact : String;
    identifiant : String;

    // Methd :
    constructor(){}
}