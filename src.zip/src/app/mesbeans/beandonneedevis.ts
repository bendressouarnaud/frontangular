export class BeanDonneDevis{

    client : String;
    contact : String;
    secteur : String;
    dureecontrat : String;
    offre : String;
    cout : String;
    dates : String;
    idauto : String;

    constructor(){}
}