export class DataGrapheCours{

    cours : string;
    mois : Number;
    tot : Number;
    id: Number;
    libmois : string;

    // Methd :
    constructor(){}
}