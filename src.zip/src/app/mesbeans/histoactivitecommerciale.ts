export class HistoActivitecommerciale{
    idacm : number;
    objectifchiffre : number;
    datedebut : String;
    datefin : String;   
    libelle : String;
    responsable : String;
    chefequipe : String;
    produit : String;

    constructor(){}
}