export class ReponseUserFulNew{
    nom : String;
    prenom : String;
    email : String;
    contact : String;
    identifiant : String;
    modes : String;
    iddone : String;
    profil : String;


    // Methd :
    constructor(){}
}