export class ReponseRdv{
    commercial : String;
    dates : String;
    heure : String;
    nom : String;
    contact : String;
    id : Number;

    // Methd :
    constructor(){}
}